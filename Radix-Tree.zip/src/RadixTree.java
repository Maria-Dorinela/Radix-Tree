
import java.util.ArrayList;

/**
 * In aceasta clasa am construit arborele si am facut metoda de cautare a unui prefix in arborele creat
 * @author Dorinela
 *
 */
public class RadixTree {
	public Node root;//root-ul arborelui
	public String string_ramas_value = "";
	public String string_ramas_node = "";
	ArrayList<Integer> rezultat = new ArrayList<Integer>();
	ArrayList<Integer> pozitii = new ArrayList<Integer>();
	ArrayList<Integer> rez = new ArrayList<Integer>();
	
	/**
	 * constructor implicit
	 * initializari
	 */
	public RadixTree(){
		root = new Node();
		root.key = "0";
		root.children = new ArrayList<Node>();
	}
	
	/**
	 * 
	 * @param n1 - primul numar
	 * @param n2 - al doilea numar
	 * @return - minimul dintre doua numere
	 */
	public int minim(int n1, int n2){
		if(n1 < n2)
			return n1;
		else
			return n2;
	}
	
	/**
	 * 
	 * @param a - primul String
	 * @param b - al doilea String
	 * @return literele comune din cele 2 stringuri
	 * 
	 */
	public ArrayList<String> verificare(String a, String b){
		ArrayList<String> result = new ArrayList<String>();
		String[] a_liters = a.toString().split("");
		String[] b_liters = b.toString().split("");
		int min = minim(a_liters.length, b_liters.length);
		string_ramas_node = "";//stringul ramas din a
		string_ramas_value = "";//stringul ramas din b
		int j;
		for(int i = 1; i < min; i++){
			if(a_liters[i].equals(b_liters[i])==true)
				result.add(a_liters[i]);
			else
			{
				
				break;
			}
		}
		int nr_elemente_result = result.size();
		for(j = nr_elemente_result+1; j < a_liters.length; j++)
		string_ramas_node += a_liters[j];
		for(j = nr_elemente_result+1; j < b_liters.length; j++)
		string_ramas_value += b_liters[j];
		return result;
	}
	
	/**
	 * Metoda care creazaarborele
	 * @param input - index
	 * @param pozitie - pozitie index in fisier
	 * @param nod - nod arbore
	 */
	public void insert(String input, int pozitie, Node nod){
		Node node = new Node();//creare nod cu key = input
		node.key = input;
	
		//pentru primul index inserat in arbore(care se afla pe pozitia 0 in ArrayList)
		//fac legaturie intre node si root
		if(pozitie == 0){
			node.parent = nod;
			nod.children.add(node);
			node.positions.add(pozitie);
		}
		else{
			int nr_children = nod.children.size();
			for(int i = 0; i < nr_children; i++){
				ArrayList<String> result = new ArrayList<String>();//in acest ArrayList introduc literele comune dintre prefixul cautat si valoarea nodului
				result = verificare(nod.children.get(i).key, node.key);
				if(result.size() >= 1){//daca am gasit litere comune intre prefix si valoarea din nod
					ArrayList<Integer> p = new ArrayList<Integer>(nod.children.get(i).positions);//ArrayList cu pozitiile nodului pana sa introduc alt nod
					int nr_children1 = nod.children.get(i).children.size();
					if(nr_children1 == 0){
						//daca au mai ramas litere in valoarea nodului si in prefix
						//fac legaturile
						if(!string_ramas_node.equals("") && !string_ramas_value.equals("")){
							if(result.size() == 1){//daca am o singura litera comuna
								nod.children.get(i).key = result.get(0);
								Node n1 = new Node(string_ramas_node, nod.children.get(i));
								Node n2 = new Node(string_ramas_value, nod.children.get(i));
								nod.children.get(i).children.add(n1);
								nod.children.get(i).children.add(n2);
								n1.positions.addAll(p);
								nod.children.get(i).positions.removeAll(nod.children.get(i).positions);
								n2.positions.add(pozitie);
							}
							else {//daca am mai multe litere comune
								String compus = "";
								for(int k = 0; k < result.size(); k++){
									compus += result.get(k);//creez un string cu litere comune
								}
								nod.children.get(i).key = compus;
								Node n11 = new Node(string_ramas_node, nod.children.get(i));
								Node n21 = new Node(string_ramas_value, nod.children.get(i));
								nod.children.get(i).children.add(n11);
								nod.children.get(i).children.add(n21);
								n11.positions.addAll(p);
								nod.children.get(i).positions.removeAll(nod.children.get(i).positions);
								n21.positions.add(pozitie);
							}
							
						}
						//daca au mai ramas litere din valoarea nodului
						//fac legaturile
						else if(!string_ramas_node.equals("") && string_ramas_value.equals("")){
							if(result.size() == 1){//daca exista o singura litera comuna
								nod.children.get(i).key = result.get(0);
								Node n1 = new Node(string_ramas_node, nod.children.get(i));
								nod.children.get(i).children.add(n1);
								n1.positions.addAll(p);
								nod.children.get(i).positions.removeAll(nod.children.get(i).positions);
								nod.children.get(i).positions.add(pozitie);
							}
							else{//daca sunt mai multe litere comune
								String compus = "";
								for(int k = 0; k < result.size(); k++){
									compus += result.get(k);//creez un string cu literele comune
								}
								nod.children.get(i).key = compus;
								Node n11 = new Node(string_ramas_node, nod.children.get(i));
								n11.positions.addAll(p);
								nod.children.get(i).positions.add(pozitie);
							}
						}
						//daca au mai ramas litere in prefix
						//fac legaturile
						else if(string_ramas_node.equals("") && !string_ramas_value.equals("")){
							if(result.size() == 1){//daca exista o singura litera comuna
								nod.children.get(i).key = result.get(0);
								Node n1 = new Node(string_ramas_value, nod.children.get(i));
								nod.children.get(i).children.add(n1);
								n1.positions.add(pozitie);
							}
							else{//daca sunt mai multe litere comune
								String compus = "";
								for(int k = 0; k < result.size(); k++){
									compus += result.get(k);//creez un string cu literele comune
								}
								nod.children.get(i).key = compus;
								Node n11 = new Node(string_ramas_value, nod.children.get(i));
								nod.children.get(i).children.add(n11);
								n11.positions.add(pozitie);
							}
						}
						//prefixul si valoare din nod sunt identice
						//adaug decat pozitia specifica prefixului la ArrayList-ul de poziti al nodului
						else if(string_ramas_node.equals("") && string_ramas_value.equals("")){
							nod.children.get(i).positions.add(pozitie);
						}
				}
					else{
						//recursivitate
						insert(string_ramas_value, pozitie, nod.children.get(i));
					}
					break;
				}
				//daca nu avem elemente comune si nu am ajuns la sfarsit 
				else if (result.size() == 0 && i != nr_children - 1){
					continue;
				}
				//daca nu avem elemente comune si am parcurs toate nodurile
				//fac legaturile
				else if(result.size() == 0 && i == nr_children - 1){
					nod.children.add(node);
					node.parent = nod;
					node.positions.add(pozitie);
					break;
				}
			}
		}
	}
	
	/**
	 * 
	 * @param n - nod arbore
	 * @return pozitiile nodurilor din arbore
	 */
	
	public ArrayList<Integer> parcurgere(Node n){
		ArrayList<Integer> r = new ArrayList<Integer>();
		if(n != null){
		for(int i = 0; i < n.children.size(); i++)
		{
			r.addAll(n.children.get(i).positions);
			rez.addAll(n.children.get(i).positions);
			parcurgere(n.children.get(i));
		}
		}
		return r;
	}
	
	/**
	 * 
	 * @param prefix - prefixul cautat in arbore
	 * @param n - nod arbore
	 * @return  - pozitiile unde se gaseste prefixul
	 */
	public ArrayList<Integer> cautare(String prefix, Node n){
		pozitii.removeAll(pozitii);
		for(int i = 0 ; i < n.children.size(); i++){
			ArrayList<Integer> rezult = new ArrayList<Integer>();
			ArrayList<String> liters = verificare(n.children.get(i).key, prefix);
			int dimensiune = liters.size();
			if(dimensiune == 0){
			}
			else{
				if(string_ramas_value.equals("")){ 
					parcurgere(n.children.get(i));
					pozitii = rez;
					pozitii.addAll(n.children.get(i).positions);
					int dim = pozitii.size();
					rezultat = pozitii;
					rezultat.add(0, dim);
					break;
				}
				else{
					cautare(string_ramas_value, n.children.get(i));
				}
				
			}	
		}
		return rezultat;
	}
    
   /**
    * parcurgere in adancime si afisare valori din nodurile arborelui si pozitile aferente nodurilor
    * @param n
    */
	public void afisare(Node n){
		if(n != null){
			System.out.println(n.key + " ----> " + n.positions);
			for(int i = 0; i < n.children.size(); i++)
				afisare(n.children.get(i));
			System.out.println("");
		}
	}
}