import java.util.ArrayList;
import java.lang.*;
import java.util.*;
/**
 * In aceasta clasa imi creez structura
 * @author Dorinela
 *
 */

public class Node {
	
	public ArrayList<Node> children;//copii unui nod
	public ArrayList<Integer> positions;//pozitiile unui nod
	public String key;//valoare din nod
	public Node parent;//parintele unui nod
	
	/**
	 * constructor implicit
	 * initilizare campuri structura
	 */
	
	public Node(){
		this.positions = new ArrayList<Integer>();
		this.children = new ArrayList<Node>();
		this.key = null;
		this.parent = null;
		
	}
	/**
	 * constructor cu 2 parametri
	 * @param key
	 * @param parent
	 */
	public Node(String key, Node parent){
		this.positions = new ArrayList<Integer>();
		this.children = new ArrayList<Node>();
		this.key = key;
		this.parent = parent;
	}
	
}



