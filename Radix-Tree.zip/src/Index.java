import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.SortedSet;
/**
 * Clasa ce contine metoda main
 * @author Dorinela
 *
 */
public class Index {
	public static ArrayList<String> cuvinte = new ArrayList<String>();//cuvintele din fisierele index
	public static ArrayList<String> prefixe = new ArrayList<String>();//prefixele pe care le caut
	public static int i,j;
	
	
	/**
	 * Execution entry point.
	 *
	 * @param args two strings representing the name of the file that contains the text to index,
	 * and the name of the file containing words to lookup in the text.
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			System.err.println("Usage: java -cp <classpath> Index <text file> <word file>");
			System.exit(1);
		}

		// TODO: replace with homework implementation:

		String word;
		Index index = new Index();

		FileParser textFile = new FileParser(args[0]);
		textFile.open();
		
		while ((word = textFile.getNextWord()) != null) {
			index.cuvinte.add(word);//introduc cuvintele in ArrayList-ul "cuvinte"
		}
		textFile.close();

		FileParser prefixFile = new FileParser(args[1]);
		prefixFile.open();
		
		while ((word = prefixFile.getNextWord()) != null) {
			index.prefixe.add(word);//introduc prefixele in ArrayList-ul "prefixe"
		}
		prefixFile.close();
		
		
		RadixTree t = new RadixTree();
		for (i = 0; i < index.cuvinte.size(); i++){
			t.insert(index.cuvinte.get(i), i, t.root);//apelez metoda care creaza arborele
		}
		 for(j = 0; j < index.prefixe.size(); j++){//parcurg ArrayList-ul cu prefixe si caut fiecare prefix in arbore
		       ArrayList<Integer> rrr =new ArrayList<Integer>();
		       t.rezultat.removeAll(t.rezultat);
		       rrr = t.cautare(index.prefixe.get(j), t.root);//apelez functia de cautare in arbore
		       int numar=0;
		  	   ArrayList<Integer> pozitie = new ArrayList<Integer>();//ArrayList cu pozitiile prefixelor
		  	   if(t.rezultat.size() != 0){
		  	   numar = t.rezultat.get(0);
		  	   t.rezultat.remove(0);
		  	   HashSet<Integer> listToSet = new HashSet<Integer>(t.rezultat);
		  	   pozitie = new ArrayList<Integer>(listToSet);
		  	   Collections.sort(pozitie);//sortez ArrayList-ul cu pozitiile gasite pentru fiecare prefix
		  	   pozitie.add(0,numar);
		}
		 //afisare rezultate obtinute
		 if(pozitie.size() == 0)
		  		System.out.print("0");
		 else{
			 	for(i = 0; i < pozitie.size(); i++)
		  			System.out.print(pozitie.get(i) + " ");
		  		}
		  	System.out.println("");	
		  }     
	}
}

