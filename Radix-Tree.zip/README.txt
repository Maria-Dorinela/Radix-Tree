Sirbu Maria-Dorinela
332CB
Tema 1 - Radix Tree

Pentru rezolvarea acestei teme am implementat algoritmul din enunt(Radix Tree) si am pornit de la scheletul dat.

Clasa Node:
	- in acesta clasa am creat o structura specifica unui arbore;
	- structura contine: 
						- String key = valoarea din nod;
						- Node parent = parintele nodului;
						- ArrayList<Integer> position = pozitile in fisierul index a nodului;
						- ArrayList<Node> children = copii nodului;
	- clasa contine doi constructori: constructorul implicit in care am initializat campurile din structura
									 si un constructor cu doi parametri;
									 
Clasa RadixTree:
	- in aceasta clasa am creat arborele si l-am parcurs pentru obtinerea pozitiilor fiecariu prefix
	- clasa contine:
				- constructorul implicit in care am facut initializarile necesare;
				- metoda "minim" care returneaza minimul intre 2 numere;
				- metoda "verificare" care returneaza un ArrayList<String> cu literele identice dintre doua stringuri.
				  In momentul in care s-a gasit o litera diferita se iese si se returneaza ArrayList-ul;
				- metoda "insert" care construieste arborele prin inserarea fiecarui index;
				- metoda "parcurgere" care returneazaun ArrayList cu pozitile nodurilor din arbore;
				- metoda "cautare" care cauta un prefix in arbore si returneaza un ArrayList cu pozitile unde se gaseste prefixul in text;
				- metoda "afisare" - afisarea arborelui;

Clasa Index:
	- contine metoda main;
	- in aceasta clasa introduc cuvintele din fisierele index si prefix in ArrayList-uri;
	- apelez metodele de mai sus pentru a afla pozitiile fiecarui prefix in text.

Clasa FileParser:
	- este clasa data in schelet.